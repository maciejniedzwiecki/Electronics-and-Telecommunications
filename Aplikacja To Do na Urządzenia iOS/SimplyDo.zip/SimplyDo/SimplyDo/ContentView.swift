//
//  ContentView.swift
//  SimplyDo
//
//  Created by Student on 01/01/2025.
//

import SwiftUI
import SwiftData

// Główny widok aplikacji, wyświetla listę zadań do wykonania
public struct ContentView: View {
    
    @Environment(\.modelContext) var context // Kontekst modelu danych
    @State private var showCreate = false // Flaga sterująca pokazaniem widoku tworzenia nowego zadania
    @State private var toDoEdit: ToDoItem? // Zadanie do edycji
    @State private var showCompleted = false // Przełącznik widoku ukończonych zadań
    @State private var searchText = "" // Tekst wyszukiwania
    
    @Query private var items: [ToDoItem] // Pobieranie listy zadań
    
    public var body: some View {
        NavigationStack {
            VStack(alignment: .center) {
                // Tytuł aplikacji
                Text("SimplyDo")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                    .padding(.horizontal)
                Text(showCompleted ? "Completed Tasks" : "To Do Tasks")
                    .font(.title2)
                    .foregroundColor(.gray)
                    .padding(.horizontal)

                List {
                    // Wyświetlanie zadań z listy z wbudowanym filtrowaniem
                    ForEach(items.filter { item in
                        (item.isCompleted == showCompleted) &&
                        (searchText.isEmpty || item.title.localizedCaseInsensitiveContains(searchText))
                    }) { item in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(item.title) // Wyświetlanie tytułu zadania
                                    .font(.title2)
                                    .bold()
                                
                                Text("\(item.timestamp, format: Date.FormatStyle(date: .numeric, time: .shortened))") // Data utworzenia
                                    .font(.callout)
                                    .foregroundColor(.gray)
                            }
                            Spacer() // Rozdzielanie elementów w wierszu
                            Button {
                                withAnimation {
                                    item.isCompleted.toggle()
                                }
                            } label: {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(item.isCompleted ? .green : .gray)
                                    .font(.largeTitle)
                            }
                            .buttonStyle(.plain) // Styl bez dodatkowych efektów
                        }
                        .swipeActions(edge: .trailing) {
                            Button(role: .destructive) {
                                withAnimation {
                                    context.delete(item)
                                }
                            } label: {
                                Label("Delete", systemImage: "trash.fill")
                            }
                            Button {
                                toDoEdit = item
                            } label: {
                                Label("Edit", systemImage: "square.and.pencil")
                            }
                            .tint(.blue)
                        }
                    }
                }
                .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always)) // Pasek wyszukiwania
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) { // Przycisk przełączania widoku
                        Button(showCompleted ? "Show To Do" : "Show Completed") {
                            withAnimation {
                                showCompleted.toggle()
                            }
                        }
                    }
                    ToolbarItem { // Przycisk dodawania nowego zadania
                        Button(action: {
                            showCreate.toggle()
                        }, label: {
                            Label("Add Item", systemImage: "plus")
                        })
                    }
                }
                .sheet(isPresented: $showCreate) { // Wyświetlanie widoku tworzenia nowego zadania
                    NavigationStack {
                        CreateToDoView()
                    }
                    .presentationDetents([.medium])
                }
                .sheet(item: $toDoEdit) { // Wyświetlanie widoku edycji zadania
                    toDoEdit = nil
                } content: { item in
                    NavigationStack {
                        UpdateToDoView(item: item)
                    }
                    .presentationDetents([.medium])
                }
            }
        }
    }
}
