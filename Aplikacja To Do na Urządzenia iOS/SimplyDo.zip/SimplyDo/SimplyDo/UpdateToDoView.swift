//
//  UpdateToDoView.swift
//  SimplyDo
//
//  Created by Student on 01/01/2025.
//

import SwiftUI
import SwiftData

// Widok do edycji istniejącego zadania
struct UpdateToDoView: View {
    
    @Environment(\.dismiss) var dismiss // Funkcja zamykania widoku
    
    @Bindable var item: ToDoItem // Zadanie do edycji
    
    var body: some View {
        Form {
            Section(header: Text("Task Details")) {
                TextField("Edit Task Name", text: $item.title) // Pole tekstowe do zmiany tytułu zadania
                DatePicker("Choose a date",
                           selection: $item.timestamp) // Wybór nowej daty
            }
            Section {
                Button("Update") { // Przycisk do zapisania zmian
                    dismiss()
                }
            }
        }
        .navigationTitle("Update Your SimplyDo") // Tytuł widoku
    }
}
