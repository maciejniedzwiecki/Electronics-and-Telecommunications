//
//  ToDoItem.swift
//  SimplyDo
//
//  Created by Student on 01/01/2025.
//

// ToDoItem.swift
import Foundation
import SwiftData

// Model reprezentujący pojedyncze zadanie
@Model
final class ToDoItem {
    var title: String // Tytuł zadania
    var timestamp: Date // Data utworzenia
    var isCompleted: Bool // Status ukończenia
    
    // Konstruktor inicjujący domyślne wartości dla zadania
    init(title: String = "",
         timestamp: Date = .now,
         isCompleted: Bool = false) {
        self.title = title
        self.timestamp = timestamp
        self.isCompleted = isCompleted
    }
}

