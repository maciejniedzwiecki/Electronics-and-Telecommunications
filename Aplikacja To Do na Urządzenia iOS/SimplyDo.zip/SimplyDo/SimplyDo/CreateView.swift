//
//  CreateView.swift
//  SimplyDo
//
//  Created by Student on 01/01/2025.
//

import SwiftUI

// Widok do tworzenia nowego zadania
struct CreateToDoView: View {
    
    @Environment(\.dismiss) var dismiss // Funkcja zamykania widoku
    @Environment(\.modelContext) var context // Kontekst modelu danych
    
    @State private var item = ToDoItem() // Nowe zadanie
    
    var body: some View {
        Form {
            Section(header: Text("Task Details")) {
                TextField("Enter Task Name", text: $item.title) // Pole tekstowe do wprowadzania tytułu zadania
                DatePicker("Choose a date",
                           selection: $item.timestamp) // Wybór daty zadania
            }
            Section {
                Button("Create") { // Przycisk do zapisania nowego zadania
                    withAnimation {
                        context.insert(item)
                    }
                    dismiss()
                }
            }
        }
        .navigationTitle("Create Your SimplyDo") // Tytuł widoku
    }
}
